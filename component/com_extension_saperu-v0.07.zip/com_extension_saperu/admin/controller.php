<?php
defined('_JEXEC') or die('Restricted access');
class SaperuController extends JControllerForm
{
	protected $default_view = 'settings';
}
